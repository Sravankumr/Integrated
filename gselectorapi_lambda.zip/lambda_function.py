import json
from zeep import Client


def read_json():

    with open('iHM-GS-Stations.json', 'r') as f:
        raw_data = json.loads(f.read())

    return raw_data

    # soap_req_server_list = []
    #
    # for data in raw_data:
    #     soap_req_server_list.append((data["GSelectorSettings"]["GSDatabaseInfo"]["Server"]).lower())
    #
    # return set(soap_req_server_list)


def lambda_handler(event, context):

    raw_data = read_json()
    response_list = []

    for station in raw_data:
        servername = (station["GSelectorSettings"]["GSDatabaseInfo"]["Server"]).lower()
        client = Client(f'''http://{servername}.usa.ccu.clearchannel.com/gsimportexportservice/gsimportexportservice.asmx?wsdl''')
        request_data = {'stationID': station["GSelectorSettings"]["GSStationInfo"]["ID"], 'schedID': 1, 'strDateTimeFrom': '2020-01-26T09:07:21', 'strDateTimeTo': '2020-01-27T09:07:21', 'details': "true", 'ignorePastSchedule': "true"}
        response = client.service.GetStationSchedule(**request_data)
        response_list.append(response)

    return {
        'statusCode': 200,
        'body': json.dumps(response_list)
    }


